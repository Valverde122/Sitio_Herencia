<?php

 class Perro extends animal{
    public function Comiendo(){
        echo "Perro comiendo huesos";
        }
  
    public function Protected(){
        $this->dormir();
    }
}