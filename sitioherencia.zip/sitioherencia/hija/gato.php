<?php

class Gato extends animal{
 function gato(){
    echo "usando protected del padre";
   echo $this->comiendo();//es protected en padre
    
    }
    public function Protected(){
       echo $this->dormir();
    }
}