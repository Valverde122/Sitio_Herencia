<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Ejercicio Herencia</h2>
    <?php

    require('./padre/animal.php');
    require('./hija/gato.php');
    require('./hija/perro.php');
    
    $perro=new Perro();
    $perro->comiendo();
    echo "<br />";
    $perro=new Perro();
    $perro->Protected();
    echo "<br />";

    $gato=new Gato();
    $gato->comiendo();
    echo "<br />";
    $gato=new Gato();
    $gato->Protected();

    ?>
</body>
</html>