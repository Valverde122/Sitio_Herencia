<?php
abstract class Animal{

    public function Comiendo(){
    echo "Animal comiendo";
    }

    protected function Dormir(){
    echo "Animal durmiendo";
    }   
}